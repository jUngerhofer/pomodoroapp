//
//  PomodoroManager.swift
//  Leodoru
//
//  Created by Ungerhofer Julian on 24.11.26.
//

import Foundation
import SwiftUI

class PomodoroManager{
    
}
