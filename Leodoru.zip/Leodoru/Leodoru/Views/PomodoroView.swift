//
//  PomodoroView.swift
//  Leodoru
//
//  Created by Ungerhofer Julian on 24.11.26.
//

import PomodoroView: View{
var body: some View{
    @State var viewModel = PomodoroViewModel(pomodoroManager: PomodoroManager())
    Text("Hello World!")
        .font(.title)
        .padding([.leading,.trailing], 20)
        .padding(.top, 30)
    
    Spacer()
    
    ZStack{
        CircularProgressView(progress: viewModel, color: viewModel.progressColor)
            .opacity(viewModel.isProgressVisible ? 1 : 0)
        Image("Pomodoro")
            .resizable()
            .scaledToFit()
            .frame(width: 200, height: 200)
    }
    .padding(50)
    
    Spacer()
    
    Text("Hello World")
        .font(.largeTitle)
        .bold()
}.background(PomodoroViewModel.progressColor)
    .opacity(0.5)
    .task{
        //TODO: START TIMER
        
    }
    .onDisappear(){
        print("pomodoro timer dismissed")
        //TODO: STOP TIMER
    }
}

#Preview{
    PomodoroView()
}
