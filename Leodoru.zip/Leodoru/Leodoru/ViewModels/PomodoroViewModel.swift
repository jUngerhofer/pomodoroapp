//
//  PomodoroViewModel.swift
//  Leodoru
//
//  Created by Ungerhofer Julian on 24.11.26.
//

import Foundation
import SwiftUI

@Observable
class PomodoroViewModel{
    var pomodoroManager: PomodoroManager
    
    var progress: Double
    var progressColor: Color
    var isProgressVisible: Bool
    
    init{
        progressColor = .pomodoroRed
        progress = 0.0
        isProgressVisible = true
        
        self.pomodoroManager = pomodoroManager
    }
    
}
